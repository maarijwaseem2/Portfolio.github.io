let menuicon = document.querySelector("#menu-icon");
let navbar = document.querySelector(".navbar");

menuicon.onclick = () => {
  menuicon.classList.toggle("bx-x");
  navbar.classList.toggle("active");
};

let section = document.querySelectorAll("section");
let navlink = document.querySelectorAll("header nav a");

window.onscroll = () => {
  section.forEach((sec) => {
    let top = window.scrollY;
    let offset = sec.offsetTop - 150;
    let height = sec.offsetHeight;
    let id = sec.getAttribute("id");

    if (top >= offset && top < offset + height) {
      navlink.forEach((link) => {
        link.classList.remove("active");
        document
          .querySelector("header nav a[href*=" + id + "]")
          .classList.add("active");
      });
    }
  });
  let header = document.querySelector("header");

  header.classList.toggle("sticky", window.screenY > 100);

  menuicon.classList.remove("bx-x");
  navbar.classList.remove("active");
};
ScrollReveal({
  // reset: true,
  distance: "80px",
  duration: 2000,
  delay: 200,
});
ScrollReveal().reveal(".home-content, .heading", { origin: "top" });
ScrollReveal().reveal(
  ".home-img, .services-container, .portfolio-box, .contact form",
  { origin: "bottom" }
);
ScrollReveal().reveal(".home-content h1, .about-img", { origin: "left" });
ScrollReveal().reveal(".home-content p, .about-content", { origin: "right" });

var typed = new Typed("#element", {
  strings: ["<i>Frontend Developer!</i>"],
  typeSpeed: 50,
});
// web development
let fullDescription_Web_Development = `
      Web development encompasses a wide range of tasks and technologies. It involves frontend development,
      where HTML, CSS, and JavaScript are used to create the user interface and enhance user experience.
      JavaScript plays a critical role in adding dynamic behavior to web pages, making them more interactive
      and responsive.</br>

      On the other hand, backend development involves server-side scripting and managing databases to handle
      data storage and retrieval. Popular backend technologies include Node.js, Python, Ruby, PHP, and more.</br>

      Full-stack developers have expertise in both frontend and backend development, enabling them to build
      complete web applications from scratch to deployment.</br>

      Web development frameworks and libraries, such as React, Angular, Vue.js, and Express.js, provide
      developers with pre-built components and tools that streamline the development process and improve
      efficiency.</br>

      Additionally, web developers must consider factors like responsive design, cross-browser compatibility,
      and web accessibility to ensure their websites are user-friendly and accessible to all users.</br>

      As the digital landscape evolves, web developers need to stay updated with the latest trends, security
      practices, and advancements in technology to create modern, secure, and high-performance web solutions.</br>

      In summary, web development is a dynamic field that continues to grow, empowering developers to craft
      engaging web experiences and shape the way we interact with information and services on the internet.
    `;

    let isFullDescriptionVisible_web = false;

    function webtoggleDescription() {
      let descriptionElement_web = document.getElementById("web_description");
      let readMoreBtn_web = document.querySelector(".web");
      
      if (isFullDescriptionVisible_web) {
        descriptionElement_web.innerHTML = `
          Web development is the process of creating, building, and maintaining websites and web applications.
          Web developers use programming languages like HTML, CSS, and JavaScript to structure web content,
          style it.
        `;
        readMoreBtn_web.textContent = "Read More";
      } else {
        descriptionElement_web.innerHTML = fullDescription_Web_Development;
        readMoreBtn_web.textContent = "Read Less";
      }

      isFullDescriptionVisible_web = !isFullDescriptionVisible_web;
    }

    // grahics designer
    let fullDescription_Graphics_Designer = `
      Graphics designers have access to a wide range of facilities that enable them to create visually stunning and impactful designs.
      Some of the key facilities available to graphics designers include:</br></br>

      1. High-performance Computers: Graphics designers require powerful computers with advanced processors, ample RAM, and dedicated graphics cards to handle resource-intensive design software and large files efficiently.</br>

      2. Design Software: Graphics designers use industry-standard software like Adobe Creative Suite (Photoshop, Illustrator, InDesign) and other specialized tools to create and manipulate images, illustrations, and layouts.</br>

      3. Graphics Tablets: These devices allow designers to draw directly on the screen, providing a more natural and precise way to create digital artwork compared to using a mouse.</br>

      4. High-resolution Displays: High-quality monitors with accurate color representation are essential for graphics designers to view their work accurately and ensure consistency in color and design elements.</br>

      5. Online Resources: Graphics designers have access to vast libraries of stock images, icons, fonts, and design templates available online, which can be used to enhance their creative projects.</br>

      6. Creative Workspaces: A well-designed and inspiring workspace can boost a graphics designer's productivity and creativity, providing a comfortable environment to work in.</br>

      These facilities empower graphics designers to bring their creative visions to life and deliver visually captivating designs across various industries and projects.`;

    let isFullDescriptionVisible_graphics = false;

    function graphicstoggleDescription() {
      let descriptionElement_graphics = document.getElementById("graphics_description");
      let readMoreBtn_graphics = document.querySelector(".graphics");

      if (isFullDescriptionVisible_graphics) {
        descriptionElement_graphics.innerHTML = `Graphics designers have access to powerful computers, design software, and graphics tablets. They use online resources, collaborate digitally. Continuous learning and portfolio platforms further enhance their work.`;
        
        readMoreBtn_graphics.textContent = "Read More";
      } 
      else {
        descriptionElement_graphics.innerHTML = fullDescription_Graphics_Designer;
        readMoreBtn_graphics.textContent = "Read Less";
      }
      isFullDescriptionVisible_graphics = !isFullDescriptionVisible_graphics;
    }


    var fullDescription_digital = `
      Digital marketing offers a wide range of facilities to efficiently promote products and services online.
      Some key facilities available in digital marketing:</br>

      1. Social Media Platforms: Digital marketers utilize popular social media platforms like Facebook, Instagram, and Twitter to reach and engage with a vast audience, running targeted advertising campaigns and building brand awareness.</br>

      2. Search Engine Optimization (SEO): SEO techniques help improve a website's visibility in search engine results, increasing organic traffic and enhancing online presence.</br>

      3. Pay-Per-Click (PPC) Advertising: Digital marketers can run PPC campaigns on search engines and social media, paying only when users click on their ads, ensuring cost-effective and targeted advertising.</br>

      4. Content Marketing: Content creation and distribution play a vital role in digital marketing, with facilities like blogs, videos, infographics, and podcasts used to provide value to the audience and establish authority.</br>

      5. Email Marketing: This facility allows marketers to directly communicate with their audience through personalized emails, promoting products, sharing updates, and nurturing customer relationships.</br>

      6. Web Analytics Tools: Digital marketers use analytics platforms like Google Analytics to monitor website traffic, user behavior, and campaign performance, providing valuable insights for data-driven decision-making.</br>

      7. E-commerce Platforms: For businesses selling products e-commerce platforms offer facilities to manage inventory, process transactions, and optimize the user experience.</br>

      8. Customer Relationship Management (CRM) Systems: CRM tools help manage customer data, track interactions, and improve customer support, enhancing overall marketing efforts.
    `;

    var isFullDescriptionVisible_digital = false;

    function digitaltoggleDescription() {
      var descriptionElement_digital = document.getElementById("description_digital");
      var readMoreBtn_digital = document.querySelector(".digital");

      if (isFullDescriptionVisible_digital) {
        descriptionElement_digital.innerHTML =
        "Digital marketing facilities: social media engagement, SEO for visibility, PPC advertising, content marketing, email campaigns, web analytics, automation tools, e-commerce platforms and influencer marketing.";
        readMoreBtn_digital.textContent = "Read More";
      } else {
        descriptionElement_digital.innerHTML = fullDescription_digital;
        readMoreBtn_digital.textContent = "Read Less";
      }

      isFullDescriptionVisible_digital = !isFullDescriptionVisible_digital;
    }


    // Introduction
    let fullDescription_introduction = `Hello everyone,</br>

    I am delighted to introduce myself as Syed Abdul Maarij, a dedicated and enthusiastic student currently pursuing my bachelor's degree in Computer Science at FAST University. As I enter my third year of studies, I find myself increasingly captivated by the captivating world of web development.</br></br>
    
    Web development has become my true passion, and I am drawn to the art of crafting visually stunning and user-centric websites and applications. My journey into the realm of web development started with small projects in web designing, where I quickly honed my skills and discovered the power of HTML, CSS, JavaScript, Bootstrap, C, and C++. These versatile tools have allowed me to create interactive and aesthetically pleasing web experiences.</br></br>
    
    As I continue my academic journey, I envision myself as a future full stack developer. My ambition is to master not only the frontend technologies but also delve into the intricacies of backend development. By combining my passion for design with a deep understanding of server-side programming, I aim to create comprehensive and seamless web solutions that leave a lasting impact.</br></br>
    
    In my free time, you can find me exploring new design trends, participating in coding challenges, or contributing to open-source projects. I believe that giving back to the community is crucial, and I aspire to share my knowledge and experiences with aspiring developers.</br></br>
    
    I am excited about the endless possibilities that lie ahead on my journey to becoming a full stack developer. With unwavering passion and a commitment to excellence, I am determined to turn my dreams into reality and make a meaningful impact in the world of web development.`;

    var isFullDescriptionVisible_introduction = false;
    function toggleintroduction(){
      let descriptionElement_introduction = document.getElementById("introduction_description");
      let readMoreBtn_introduction = document.querySelector(".introduction");

      if (isFullDescriptionVisible_introduction) {
        descriptionElement_introduction.innerHTML =
        `Hello, everyone!</br>My name is Syed Abdul Maarij, and I am a passionate frontend developer.<br> 
        With a keen eye for design and a love for crafting seamless user experiences,<br>
        I specialize in creating engaging and user-friendly interfaces for
        websites and web applications.`;
        readMoreBtn_introduction.textContent = "Read More";
      } else {
        descriptionElement_introduction.innerHTML = fullDescription_introduction;
        readMoreBtn_introduction.textContent = "Read Less";
      }

      isFullDescriptionVisible_introduction = !isFullDescriptionVisible_introduction;      
    }








    function sendEmail() {
      Email.send({
        Host: "smtp.gmail.com",
        Username: "sender@email_address.com",
        Password: "Enter your password",
        To: 'receiver@email_address.com',
        From: "sender@email_address.com",
        Subject: "Sending Email using javascript",
        Body: "Well that was easy!!",
      })
        .then(function (message) {
          alert("mail sent successfully")
        });
    }